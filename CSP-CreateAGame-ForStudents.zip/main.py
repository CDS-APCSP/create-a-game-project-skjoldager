import os, time

health = 100
gun = False 
sword = False
characterList = ["Heath", "Aidan", "Max"]
character = ""

def startgame():
  global character
  os.system('clear') # clear the screen for the player
print("Welcome explorers! you will be navigating through the underground caves of Cavinaria.")
print("Choose a character from the character list.")
print(characterList)
character = input(">>")
if character == "Heath":
    gun = True
print ("you have health and gun")
if character == "Aidan":
  sword = True 
print("you have health and sword")
if character == "Max":
  print ("you have health")
  print()
  print()
  print("Let's get started!")
  time.sleep(5) # wait 3 seconds before moving on
  cave1() # runs to send the player to cave #1

def cave1():
  # global shovel # use the shovel variable from the top
  global gun, sword
  os.system('clear')
  print("You are in the first cave. Would you like to take the tunnel to your left or to your right?")
if character == "Heath":
  cave2() #run player into cave #2
  if character == "Aidan" and "right":
    print ("you make it to cave 2 without trouble")
    cave2()
    else 
    print("You are in the first cave. There is a sword on the ground, a tunnel to your left, and a tunnel to your right. What would you like to do?")
  decision = input(">>").strip().lower()
  if decision.find("shovel") > -1:
    print("Picking up the shovel.")
    shovel = True
    time.sleep(3)
    cave1()
  elif decision.find("left") > -1:
    print("You tried to dig through the tunnel and its a dead end.")
    time.sleep(3)
    cave1()
  elif decision.find("right") > -1:
    print("Digging through the tunnel on the right.")
    time.sleep(3)
    cave2()
  else:
    print("Sorry, that command is not found.")
    time.sleep(3)
    cave1()
  

def cave2():
  global explosives, health
  os.system('clear')
  print("Welcome to Cave 2")

def cave3():
  global explosives, health
  os.system('clear')
  pass

def endGame():
  os.system("clear")
  pass

startgame()

